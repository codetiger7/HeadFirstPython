
from distutils.core import setup

setup(
		name				= 'nester7711',
		version			= '1.333.0',
		py_modules  	= ['nester7711'],
		author_email 	= 'codetiger@icloud.com',
		url				= 'http://nourl',
		description		= 'A simple printer of nested lists',

		)

