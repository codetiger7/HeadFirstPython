
from distutils.core import setup

setup(
		name				= 'nester',
		version			= '1.4.0',
		py_modules  	= ['nester'],
		author_email 	= 'codetiger@icloud.com',
		url				= 'http://noUrl',
		description		= 'A simple printer of nested lists',

		)

